from .mengzi_zs import MengziZeroShot

mz = MengziZeroShot()
mz.load()

# 使用示例：
# 情感分类
res = mz.inference(task_type='sentiment_classifier', 
                   input_string='15.4寸笔记本的键盘确实爽，基本跟台式机差不多了，蛮喜欢数字小键盘，输数字特方便，样子也很美观，做工也相当不错')
print(res)

# 新闻分类
res = mz.inference(task_type='news_classifier', 
                   input_string='商赢环球股份有限公司关于延期回复上海证券交易所对公司2017年年度报告的事后审核问询函的公告')
print(res)

# input_strings = [{'task_type': 'sentiment_classifier', 
#                   'input_string':'15.4寸笔记本的键盘确实爽，基本跟台式机差不多了，蛮喜欢数字小键盘，输数字特方便，样子也很美观，做工也相当不错',
#                 #   'label_list': None
#                  },
#                  {'task_type': 'sentiment_classifier', 
#                   'input_string':'差得要命,很大股霉味,勉强住了一晚,第二天大早赶紧溜',
#                 #   'label_list': None
#                  },
#                  {'task_type': 'news_classifier', 
#                   'input_string':'商赢环球股份有限公司关于延期回复上海证券交易所对公司2017年年度报告的事后审核问询函的公告',
#                 #   'label_list': ['故事', '文化', '娱乐', '体育', '财经', '房产', '汽车', '教育', '科技', '军事', '旅游', '国际', '股票', '农业', '电竞']
#                  },
#                  {'task_type': 'news_classifier', 
#                   'input_string':'通过中介公司买了二手房，首付都付了，现在卖家不想卖了。怎么处理？',
#                 #   'label_list': ['故事', '文化', '娱乐', '体育', '财经', '房产', '汽车', '教育', '科技', '军事', '旅游', '国际', '股票', '农业', '电竞']
#                  }
#                 ]

