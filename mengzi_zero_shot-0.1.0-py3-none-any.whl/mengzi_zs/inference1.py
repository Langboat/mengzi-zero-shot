from transformers import T5Tokenizer, T5ForConditionalGeneration

# load model
model_name = "hjy/mengzi-t5-base-mt"
tokenizer = T5Tokenizer.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)

input_strings = [{'task_type': 'sentiment_classifier', 
                  'input_string':'15.4寸笔记本的键盘确实爽，基本跟台式机差不多了，蛮喜欢数字小键盘，输数字特方便，样子也很美观，做工也相当不错'},
                 {'task_type': 'sentiment_classifier', 
                  'input_string':'差得要命,很大股霉味,勉强住了一晚,第二天大早赶紧溜'}]

task_type = 'sentiment_classifier'
# map task type
def sentiment_classifier_fun(s):
    prompts = [f'评论：{s}。请判断该条评论所属类别(积极或消极)并填至空格处。回答：',
            f'"{s}"。 如果这个评论的作者是客观的，那么请问这个评论的内容是什么态度的回答？答：']
    return prompts
    # |||消极/积极 

map
task_type_map =  ['sentiment_classifier': sentiment_classifier_fun]
fun = task_type_map[task_type]

# input_demo_in_ppt = ['“导致泗水的砭石受到追捧，价格突然上涨。而泗水县文化市场综合执法局颜鲲表示，根据监控，” 找出上述句子中的实体和他们对应的类别',
#                     '“你好，我还款银行怎么更换”和“怎么更换绑定还款的卡”这两句话是在说同一件事吗？',
#                     '“为打消市场顾虑,工行两位洋股东——美国运通和安联集团昨晚做出承诺,近期不会减持工行H股。”中的“工行”和“美国运通”是什么关系？答：',
#                     '请根据以下商品信息设计广告文案。商品信息：类型-裤，版型-宽松，风格-潮，风格-复古，风格-文艺，图案-复古，裤型-直筒裤，裤腰型-高腰，裤口-毛边',
#                     '问题：“呼气试验阳性什么意思 ”。此问题的医学意图是什么？选项：病情诊断，病因分析，治疗方案，就医建议，指标解读，疾病描述，后果表述，注意事项，功效作用，医疗费用。',
#                     '“房间很一般，小，且让人感觉脏，隔音效果差，能听到走廊的人讲话，走廊光线昏暗，旁边没有什么可吃” 这条评论的态度是什么？',
#                     '评论：灵水的水质清澈，建议带个浮潜装备，可以看清湖里的小鱼。这条评论的评价对象是谁？',
#                     '这条新闻是关于什么主题的? 新闻: 懒人适合种的果树：长得多、好打理，果子多得都得送邻居吃 ']

for s in input_list:
    print('input:', s)
    input_ids = tokenizer(s, return_tensors="pt").input_ids
    outputs = model.generate(input_ids)
    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    print('output:', result)
